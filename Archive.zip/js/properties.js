// Simple properties list (add real images into /images/ and update src)
const allProperties = [
  { id:1, title:"Luxury Sea View Villa", price:"₹4,80,00,000", city:"Alibag", state:"Maharashtra", country:"India", img:"images/maha1.jpg", desc:"4 BHK villa with pool and sea view." },
  { id:2, title:"Penthouse in Pune", price:"₹2,50,00,000", city:"Pune", state:"Maharashtra", country:"India", img:"images/maha2.jpg", desc:"Spacious penthouse near Koregaon Park." },
  { id:3, title:"Mumbai Highrise Flat", price:"₹3,20,00,000", city:"Mumbai", state:"Maharashtra", country:"India", img:"images/maha3.jpg", desc:"Modern 3BHK with city skyline." },
  { id:4, title:"Bungalow near Lonavala", price:"₹1,40,00,000", city:"Lonavala", state:"Maharashtra", country:"India", img:"images/maha4.jpg", desc:"Quiet 2BHK bungalow in hills." },
  { id:5, title:"Chennai Modern Apartment", price:"₹95,00,000", city:"Chennai", state:"Tamil Nadu", country:"India", img:"images/india1.jpg", desc:"2BHK in central Chennai." },
  { id:6, title:"Delhi Family Home", price:"₹1,60,00,000", city:"Delhi", state:"Delhi", country:"India", img:"images/india2.jpg", desc:"3BHK in residential colony." },
  // add more items as needed
];

let filtered = allProperties.slice();
let renderedCount = 0;
const PAGE_SIZE = 4;

const grid = document.getElementById('propertiesGrid');
const loadMoreWrap = document.getElementById('loadMoreWrap');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const regionSelect = document.getElementById('regionSelect');

function renderNextBatch(){
  const slice = filtered.slice(renderedCount, renderedCount + PAGE_SIZE);
  slice.forEach(p => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div style="position:relative">
        <img src="${p.img}" alt="${p.title}" loading="lazy" />
        <span class="badge">Featured</span>
      </div>
      <div class="meta">
        <h3>${p.title}</h3>
        <div class="price">${p.price}</div>
        <div style="margin-top:8px;color:#666">${p.city}, ${p.state}</div>
      </div>
    `;
    card.onclick = ()=> openModal(p);
    grid.appendChild(card);
  });
  renderedCount += slice.length;
  updateLoadMoreVisibility();
}

function updateLoadMoreVisibility(){
  if(renderedCount < filtered.length){
    loadMoreWrap.hidden = false;
  } else {
    loadMoreWrap.hidden = true;
  }
}

function resetAndRender(){
  grid.innerHTML = '';
  renderedCount = 0;
  renderNextBatch();
}

// region filter
regionSelect.addEventListener('change', ()=>{
  const v = regionSelect.value;
  if(v === 'maharashtra'){
    filtered = allProperties.filter(p => p.state.toLowerCase() === 'maharashtra');
  } else {
    filtered = allProperties.slice();
  }
  resetAndRender();
});

// modal
const modal = document.getElementById('propertyModal');
const modalTitle = document.getElementById('modalTitle');
const modalPrice = document.getElementById('modalPrice');
const modalLocation = document.getElementById('modalLocation');
const modalDesc = document.getElementById('modalDesc');
const modalImage = document.getElementById('modalImage');
const modalClose = document.getElementById('modalClose');

function openModal(p){
  modalImage.src = p.img;
  modalTitle.textContent = p.title;
  modalPrice.textContent = p.price;
  modalLocation.textContent = `${p.city}, ${p.state}, ${p.country}`;
  modalDesc.textContent = p.desc;
  modal.setAttribute('aria-hidden','false');
}

function closeModal(){
  modal.setAttribute('aria-hidden','true');
  modalImage.src = '';
}
modalClose.addEventListener('click', closeModal);
modal.addEventListener('click', (e)=>{ if(e.target === modal) closeModal(); });

// Load more by button
loadMoreBtn.addEventListener('click', renderNextBatch);

// Show "Load more" when user scrolls near bottom
window.addEventListener('scroll', ()=>{
  const nearBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - 120;
  if(nearBottom && renderedCount < filtered.length){
    loadMoreWrap.hidden = false;
  }
});

// initial render
resetAndRender();